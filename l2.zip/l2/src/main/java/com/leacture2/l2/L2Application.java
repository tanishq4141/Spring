package com.leacture2.l2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L2Application {

	public static void main(String[] args) {
		SpringApplication.run(L2Application.class, args);
	}

}
